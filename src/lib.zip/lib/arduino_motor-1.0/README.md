# arduino_motor
universal library for the arduino motor
