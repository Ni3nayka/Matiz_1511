ManualAcknowledgements.cpp
==========================

.. literalinclude:: ../../../../examples_linux/manualAcknowledgements.cpp
    :lines: 7-
    :linenos:
    :lineno-match:
